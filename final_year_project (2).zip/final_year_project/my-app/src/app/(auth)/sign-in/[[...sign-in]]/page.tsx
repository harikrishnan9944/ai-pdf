import { SignIn } from '@clerk/nextjs'

export default function Page() {
  return(
<div className='flex  items-center justify-center'>
    <div className='mt-[70px]'>
    <SignIn />
    </div>

</div>
  ) 
}