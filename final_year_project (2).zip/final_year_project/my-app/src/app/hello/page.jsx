import React from 'react'

function page() {
  return (

  <>
    <section
      aria-labelledby="primary-heading"
      className="min-w-0 flex-1 h-full flex flex-col overflow-y-auto lg:order-last"
    >
      <div className="flex-grow overflow-hidden h-screen bg-scroll">
        <div className="w-full h-full flex flex-col max-w-full self-center  py-3  sm:px-3.5 md:px-4 lg:px-5 @container min-h-full">
          <div className="w-full h-full flex-1 flex flex-col max-w-full self-center ">
            <div className="flex flex-col  flex-1 w-full h-full mr-auto">
           Welcome to the Ecommerce
          </div>
          </div>
        </div>
      </div>
    </section>
  </>
  )
}

export default page