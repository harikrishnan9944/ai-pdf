// import { NextResponse } from "next/server";
// import { WebPDFLoader } from "@langchain/community/document_loaders/web/pdf";
// import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";

// const pdfUrl = "https://combative-nightingale-50.convex.cloud/api/storage/0d1cf136-3322-4d03-aee3-2108e21c54fc";

// export async function GET(req) {
//     const reqUrl=req.url;
//     const {searchParams}=new URL(reqUrl)
//     const pdfUrl=searchParams.get('pdfUrl');
//     console.log(pdfUrl)
//     try {
//         // 1. Load the PDF file
//         const response = await fetch(pdfUrl);

//         if (!response.ok) {
//             throw new Error(`Failed to fetch PDF: ${response.statusText}`);
//         }

//         const blob = await response.blob();
//         const loader = new WebPDFLoader(blob);
//         const docs = await loader.load();

//         // Combine all page content into a single string
//         let pdfTextContent = '';
//         docs.forEach(doc => {
//             pdfTextContent += doc.pageContent;
//         });

//         // 2. Split the text into smaller chunks
//         const splitter = new RecursiveCharacterTextSplitter({
//             chunkSize: 100,
//             chunkOverlap: 10, // Overlap must be smaller than chunk size
//         });

//         const output = await splitter.createDocuments([pdfTextContent]);

//         let splitterList=[];
//         output.forEach(doc=>{
//             splitterList.push(doc.pageContent);
//         })
//         return NextResponse.json({ result: splitterList });
//     } catch (error) {
//         console.error("Error loading PDF:", error);
//         return NextResponse.json({ error: "Failed to load PDF", details: error.message }, { status: 500 });
//     }
// }

import { NextResponse } from "next/server";
import { WebPDFLoader } from "@langchain/community/document_loaders/web/pdf";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";

// const pdfUrl =
//   "https://combative-nightingale-50.convex.cloud/api/storage/0d1cf136-3322-4d03-aee3-2108e21c54fc";

export async function GET(req) {
    const reqUrl=req.url
    const {searchParams}=new URL(reqUrl)
    const pdfUrl=searchParams.get('pdfUrl')
  try {
    // 1. Fetch the PDF File
    const response = await fetch(pdfUrl);
    if (!response.ok) {
      throw new Error("Failed to fetch the PDF file.");
    }

    const arrayBuffer = await response.arrayBuffer();
    const blob = new Blob([arrayBuffer], { type: "application/pdf" });

    // 2. Load the PDF using WebPDFLoader
    const loader = new WebPDFLoader(blob);
    const docs = await loader.load();

    if (!docs || docs.length === 0) {
      throw new Error("Failed to load or parse the PDF content.");
    }

    // 3. Extract the text from the PDF
    let pdfTextContent = "";
    docs.forEach((doc, index) => {
      if (!doc.pageContent) {
        console.warn(`Page ${index + 1} has no content.`);
      }
      pdfTextContent += doc.pageContent || "";
    });

    if (!pdfTextContent) {
      throw new Error("No text content extracted from the PDF.");
    }

    // 4. Split the text into small chunks
    const splitter = new RecursiveCharacterTextSplitter({
      chunkSize: 100,
      chunkOverlap: 20, // Overlap must be smaller than chunk size
    });

    const output = await splitter.createDocuments([pdfTextContent]);

        let splitterList=[];
        output.forEach(doc=>{
            splitterList.push(doc.pageContent);
        })

    if (!output || output.length === 0) {
      throw new Error("Text splitting failed or resulted in no chunks.");
    }

    // 5. Return the resulting chunks
    return NextResponse.json({ result: splitterList });
  } catch (error) {
    // Return error messages for debugging
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

