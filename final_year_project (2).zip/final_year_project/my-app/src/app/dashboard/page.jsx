import React from 'react'

function Dashboard() {
  return (
    <div className='relative'>Dashboard</div>
  )
}

export default Dashboard