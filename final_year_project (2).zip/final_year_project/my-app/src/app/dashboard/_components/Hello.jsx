import React from "react";
import { Formik } from "formik";
import { LuLoader2 } from "react-icons/lu";

const Hello = () => (
  <div>
    <h1>My Form</h1>
    <Formik
      initialValues={{
        configuration: {
          api_key: "",
          model: "",
          max_tokens: 0,
          temperature: 0,
          top_p: "",
          frequency_penalty: 0,
          presence_penalty: 0,
        },
      }}
      onSubmit={(values, { setSubmitting }) => {
        setTimeout(() => {
          console.log(values); // Log form values for debugging
          setSubmitting(false);
        }, 2000);
      }}
    >
      {({ handleSubmit, handleChange, handleBlur, values, isSubmitting }) => (
        <div className="flex justify-center items-center">
        <form
          onSubmit={handleSubmit}
          className="p-6 border bg-gray-100 shadow-2xl rounded-md w-96"
        >
          <h1 className="text-center text-xl font-semibold mb-4 text-gray-700">
            Configuration Form
          </h1>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 mb-1">
              API Key
            </label>
            <input
              type="text"
              name="configuration.api_key"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.configuration.api_key}
              placeholder="Api_Key"
              className="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Model
            </label>
            <input
              type="text"
              name="configuration.model"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.configuration.model}
              placeholder="Model"
              className="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Max Tokens
            </label>
            <input
              type="text"
              name="configuration.max_tokens"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.configuration.max_tokens}
              placeholder="Max_tokens"
              className="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Temperature
            </label>
            <input
              type="text"
              name="configuration.temperature"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.configuration.temperature}
              placeholder="Temperature"
              className="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Top P
            </label>
            <input
              type="text"
              name="configuration.top_p"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.configuration.top_p}
              placeholder="Top_p"
              className="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Frequency Penalty
            </label>
            <input
              type="text"
              name="configuration.frequency_penalty"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.configuration.frequency_penalty}
              placeholder="Frequency_penalty"
              className="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Presence Penalty
            </label>
            <input
              type="text"
              name="configuration.presence_penalty"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.configuration.presence_penalty}
              placeholder="Presence_penalty"
              className="w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full p-2 rounded-md flex justify-center items-center  text-white bg-red-400 hover:bg-black`}
          >
            {isSubmitting ? <LuLoader2 className="animate-spin text-xl font-bold " /> : 'Sumbit'}
          </button>
        </form>
        </div>
      )}
    </Formik>
  </div>
);

export default Hello;
