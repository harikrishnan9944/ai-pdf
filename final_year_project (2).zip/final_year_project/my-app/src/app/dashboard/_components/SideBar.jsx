import Image from 'next/image'
import React from 'react'
import Logo from '../../../../public/logo.svg'
import UploadPdfDialog from './UploadPdfDialog'
import { Button } from '@/components/ui/button'
import { FiLayout } from "react-icons/fi";
import { MdOutlineShield } from "react-icons/md";
import { Progress } from '@/components/ui/progress';


function SideBars() {
  return (
    <div className='h-screen shadow-md p-7'>
        <Image src={Logo} alt='Logo'/>
        <div className='mt-10 w-full'>
            <UploadPdfDialog>
            <Button className='font-semibold w-[190px]'>+  Upload PDF</Button>
            </UploadPdfDialog>
        </div>
        <div className='flex mt-5 items-center  cursor-pointer p-2  hover:bg-gray-200 rounded-lg'>
            <FiLayout className='text-2xl'/>
            <div className='flex items-center pt-1'>
            <h2 className='font-semibold pl-2'>Workspace</h2>
            </div>
            
        </div>

        <div className='flex mt-1 items-center  cursor-pointer p-2  hover:bg-gray-200 rounded-lg'>
            <MdOutlineShield className='text-2xl'/>
            <div className='flex items-center pt-1'>
            <h2 className='font-semibold pl-2'>Upgarade</h2>
            </div> 
        </div>
        <div className='mt-[18rem]'>
           <Progress value={40}/> 
           <p className='font-semibold text-sm mt-2'>2 Out of 5 Pdf Uploaded</p>
           <p className='text-sm font-semibold mt-1 text-gray-400'>Uprade to Upload more PDF</p>
        </div>
    </div>
  )
}

export default SideBars