import React from 'react';
import { UserButton } from '@clerk/nextjs';

function Header() {
  return (
    <div className="w-full ">
      <div className='flex justify-end shadow-sm p-4'>
      <UserButton />
      </div>
      </div>
  );
}

export default Header;
