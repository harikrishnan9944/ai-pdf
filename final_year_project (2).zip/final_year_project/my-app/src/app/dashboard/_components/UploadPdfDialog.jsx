'use client';
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    DialogClose,
    DialogFooter,
} from "@/components/ui/dialog";
import { useMutation, useAction } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import { useState } from "react";
import { LuLoader2 } from "react-icons/lu";
import { useUser } from "@clerk/nextjs";
import uuid4 from "uuid4";
import axios from 'axios';

const UploadPdfDialog = () => {
    const generateUploadUrl = useMutation(api.fileStorage.generateUploadUrl);
    const [file, setFile] = useState();
    const [loading, setLoading] = useState(false);
    const addFileEntry = useMutation(api.fileStorage.AddFileEntryToDb);
    const getFileUrl = useMutation(api.fileStorage.getFileUrl);
    const { user } = useUser();
    const [filename, setFileName] = useState();
    const [open, setOpen] = useState(false);
    const embeddDocument=useAction(api.myAction.ingest)

    const onFileSelect = (event) => {
        setFile(event.target.files[0]);
    };

    const onUpload = async () => {
        if (!file) {
            alert("Please select a file first!");
            return;
        }

        setLoading(true);

        try {
            
            const postUrl = await generateUploadUrl();

            const result = await fetch(postUrl, {
                method: "POST",
                headers: { "Content-Type": file?.type },
                body: file,
            });
         
           

            const { storageId } = await result.json();
            console.log("Storage ID:", storageId);

            const fileId = uuid4();
            const fileUrl = await getFileUrl({ storageId });

            
            await addFileEntry({
                createdBy: user?.primaryEmailAddress?.emailAddress,
                fileId,
                fileName: filename ?? "Untitled File",
                fileUrl,
                storageId,
            });


           
            const ApiResp = await axios.get(`/api/pdf-loader?pdfUrl=${fileUrl}`);
            console.log("API Response:", ApiResp.data.result);

            embeddDocument({
                splitText:ApiResp.data.result,
                fileId:{fileId}
            });

            alert("File uploaded successfully!");
        } catch (error) {
            console.error("File upload failed:", error);
            alert("Failed to upload the file. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open}>
            <DialogTrigger>
                <Button onClick={() => setOpen(true)} className="w-full">
                    + Upload PDF File
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Upload PDF File</DialogTitle>
                    <DialogDescription>
                        <div>
                            <h1 className="mt-5">Select a File to Upload</h1>
                            <div className="gap-2 p-3 rounded-md border">
                                <input
                                    type="file"
                                    accept="application/pdf"
                                    onChange={onFileSelect}
                                />
                            </div>
                            <div className="mt-2">
                                <label>File Name*</label>
                                <input
                                    type="text"
                                    className="w-full border py-2 rounded-md focus:outline-none focus:border-blue-500"
                                    onChange={(event) => setFileName(event.target.value)}
                                />
                            </div>
                        </div>
                    </DialogDescription>
                </DialogHeader>
                <DialogFooter className="sm:justify-end">
                    <DialogClose asChild>
                        <Button type="button" variant="secondary">
                            Close
                        </Button>
                    </DialogClose>
                    <Button onClick={onUpload} disabled={loading}>
                        {loading ? <LuLoader2 className="animate-spin" /> : "Upload"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default UploadPdfDialog;
