import { useFormik } from 'formik';
import React from 'react';

function Formiks() {
    const formik = useFormik({
        initialValues: {
            configuration: {
                api_key: "",
                model: "",
                max_tokens: 0,
                temperature: 0,
                top_p: '',
                frequency_penalty: 0,
                presence_penalty: 0,
            },
        },
        onSubmit: (values, { setSubmitting }) => {
            console.log(values);
            setTimeout(() => setSubmitting(false), 3000);
        }
    });

    return (
        <div className='flex justify-center items-center w-full h-auto bg-gray-100 py-4'>
            <form
                onSubmit={formik.handleSubmit}
                className='border bg-white shadow-lg flex flex-col p-6 w-96 rounded-md'
            >
                <h1 className="text-center text-xl font-semibold mb-4 text-gray-700">Configuration Form</h1>

                <div className='mb-4'>
                    <label className='block text-sm font-medium text-gray-600 mb-1'>Api_key</label>
                    <input
                        type="text"
                        name="configuration.api_key"
                        onChange={formik.handleChange}
                        value={formik.values.configuration.api_key}
                        placeholder='Api_Key'
                        className='w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none'
                    />
                </div>

                <div className='mb-4'>
                    <label className='block text-sm font-medium text-gray-600 mb-1'>Model</label>
                    <input
                        type="text"
                        name="configuration.model"
                        onChange={formik.handleChange}
                        value={formik.values.configuration.model}
                        placeholder='Model'
                        className='w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none'
                    />
                </div>

                <div className='mb-4'>
                    <label className='block text-sm font-medium text-gray-600 mb-1'>Max_tokens</label>
                    <input
                        type="text"
                        name="configuration.max_tokens"
                        onChange={formik.handleChange}
                        value={formik.values.configuration.max_tokens}
                        placeholder='Max_tokens'
                        className='w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none'
                    />
                </div>

                <div className='mb-4'>
                    <label className='block text-sm font-medium text-gray-600 mb-1'>Temperature</label>
                    <input
                        type="text"
                        name="configuration.temperature"
                        onChange={formik.handleChange}
                        value={formik.values.configuration.temperature}
                        placeholder='Temperature'
                        className='w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none'
                    />
                </div>

                <div className='mb-4'>
                    <label className='block text-sm font-medium text-gray-600 mb-1'>Top_P</label>
                    <input
                        type="text"
                        name="configuration.top_p"
                        onChange={formik.handleChange}
                        value={formik.values.configuration.top_p}
                        placeholder='Top_p'
                        className='w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none'
                    />
                </div>

                <div className='mb-4'>
                    <label className='block text-sm font-medium text-gray-600 mb-1'>Frequency_Penalty</label>
                    <input
                        type="text"
                        name="configuration.frequency_penalty"
                        onChange={formik.handleChange}
                        value={formik.values.configuration.frequency_penalty}
                        placeholder='Frequency_penalty'
                        className='w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none'
                    />
                </div>

                <div className='mb-4'>
                    <label className='block text-sm font-medium text-gray-600 mb-1'>Presence_Penalty</label>
                    <input
                        type="text"
                        name="configuration.presence_penalty"
                        onChange={formik.handleChange}
                        value={formik.values.configuration.presence_penalty}
                        placeholder='Presence_penalty'
                        className='w-full border border-gray-300 p-2 rounded-md focus:ring focus:ring-blue-200 focus:outline-none'
                    />
                </div>

                <button
                    type="submit"
                    disabled={formik.isSubmitting}
                    className={`w-full p-2 rounded-md text-white  py-2 px-2 bg-green-500`}
                >
                    Submit
                </button>
            </form>
        </div>
    );
}

export default Formiks;
