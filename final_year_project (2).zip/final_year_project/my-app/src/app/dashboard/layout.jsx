import React from 'react'
import Header from './_components/Header'
import SideBars from './_components/SideBar'

function DashboardLayout({ children }) {
    return (
        <div className='flex'>
            <div className='w-[300px] h-screen'>
                <SideBars />
            </div>
            <div className='w-full '>
                <Header />
               <div className='p-10'>
               {children}
               </div>
            </div>
        </div>
    )
}

export default DashboardLayout