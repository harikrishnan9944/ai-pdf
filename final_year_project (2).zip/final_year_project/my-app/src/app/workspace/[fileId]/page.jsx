'use client';
import React from 'react';
import { useParams } from 'next/navigation';
import WorkSpaceHeader from '../_componets/WorkSpaceHeader';
import PdfViewer from '../_componets/PdfViewe';
import { useAction, useQuery } from 'convex/react';
import { api } from '../../../../convex/_generated/api';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { FaWandMagicSparkles } from "react-icons/fa6";
import { getChatSession } from '../../../../configs/AIModel';
import { LuLoader2 } from "react-icons/lu";


function WorkSpace() {
  const { fileId } = useParams();
  const SearchAi = useAction(api.myAction.search);
  const fileInfo = useQuery(api.fileStorage.GetFileRecord, {
    fileId: fileId,
  });

  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: 'Let`s Talk.....!',
      }),
    ],
    editorProps: {
      attributes: {
        class: 'focus:outline-none px-5',
      },
    },
  });

  const OnAiClick = async () => {
    try {
      const selectedText = editor.state.doc.textBetween(
        editor.state.selection.from,
        editor.state.selection.to,
        ""
      );

  const result = await SearchAi({
        query: selectedText.trim(),
        fileId: fileId,
      });

      const UnformattedAns = JSON.parse(result || "[]");
      let AllUnformattedAns = '';
      UnformattedAns.forEach(item => {
        AllUnformattedAns += item.pageContent;
      });

      const PROMPT =
        `For question: ${selectedText} and with the given content as answer,` +
        ` please provide an appropriate answer in HTML format. The answer content is: ${AllUnformattedAns}`;

      const chatSession = getChatSession();
      const AiModelResult = await chatSession.sendMessage(PROMPT);
      console.log("AI Model Response:", await AiModelResult.response.text());
      const FinalAns = AiModelResult.response.text().replace(/```/g, '').replace('html', '');

      const AllText = editor.getHTML();
      editor.commands.setContent(AllText + '<p><strong> Answer:</strong>' + FinalAns + '</p>');
    } catch (error) {
      console.error("Error in OnAiClick:", error);
    }
  };

  return (
<div className="">
  <div className="">
    {fileInfo?.fileUrl ? (
      <div className="flex h-screen overflow-y-hidden">
        {/* Editor Section */}
        <div className="w-full">
          <div className="h-screen py-2 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400">
            <div className="sticky top-0 z-10 bg-white">
              <button
                onClick={OnAiClick}
                className="hover:text-blue-500 mb-4"
              >
                <FaWandMagicSparkles className="text-3xl" />
              </button>
            </div>
            <EditorContent editor={editor} />
          </div>
        </div>
        {/* PDF Viewer Section */}
        <div className="w-full">
          <PdfViewer fileUrl={fileInfo.fileUrl} />
        </div>
      </div>
   ) : (
          <div className="flex items-center justify-center w-full h-screen">
            <LuLoader2 className="text-6xl animate-spin text-black" />
          </div>
        )}
      </div>
    </div>
    );
}

export default WorkSpace;

