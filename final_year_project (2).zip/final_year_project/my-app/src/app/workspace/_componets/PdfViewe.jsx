import React from 'react';

function PdfViewe({ fileUrl }) {
  return (
    <div className="h-[90vh] py-4">
      <iframe
      onScroll={'onScroll'}
        src={fileUrl + '#toolbar=0'}
        height="100%"
        width="100%"
        className="h-screen w-full"
      />
    </div>
  );
}

export default PdfViewe;
