import Image from 'next/image'
import React from 'react'
import {UserButton} from '@clerk/nextjs'

function WorkSpaceHeader() {
  return (
    <div className='flex sticky justify-between shadow-md  px-3 items-center'>
        <Image src={'/logo'} alt='logo' width={140} height={50}/>
        <UserButton />
    </div>
  )
}

export default WorkSpaceHeader