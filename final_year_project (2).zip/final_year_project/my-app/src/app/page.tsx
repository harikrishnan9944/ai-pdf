'use client'
import { useClerk, UserButton, useUser } from "@clerk/nextjs";
import { useMutation } from "convex/react";
import Image from "next/image";
import { api } from "../../convex/_generated/api";
import { useEffect } from "react";
import Formiks from './dashboard/_components/Formik'
import Hello from './dashboard/_components/Hello'

export default   function Home() {
  const {user}=useUser();
  const CreateUser=useMutation(api.user.createUser)

  useEffect(()=>{
user&&CheckUser();
  },[user])

  const CheckUser=async()=>{
const result=await CreateUser({
email:user?.primaryEmailAddress?.emailAddress,
imageUrl:user?.imageUrl,
name:user?.fullName
});
console.log(result)
  }
  return (
    <div>
      Hello world
      <UserButton />
      {/* <Formiks /> */}
      <Hello />
    </div>
  )
}
